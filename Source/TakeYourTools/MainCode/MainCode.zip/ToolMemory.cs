﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;

using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;
using Verse.Sound;

namespace TakeYourTools
{
    public class ToolMemory : IExposable
    {
        #region ToolMemory_Properties 
        public Pawn pawn = null;
        private bool? usingTool = false; //usingTool: true,false,nullable
        private SkillDef lastCheckedSkill = null;
        private Thing previousEquipped = null;
        #endregion

        #region ToolMemory_Init
        // Init properties
        public bool IsUsingTool => (usingTool ?? false); // if null then false
        public Thing PreviousEquipped => previousEquipped;
        #endregion

        #region ToolMemory_methods
        /// <summary>
        /// Check if the pawn skills were updated
        /// </summary>
        /// <param name="skill"></param>
        /// <returns>Returns true if updated</returns>
        public bool UpdatePawnSkill(SkillDef skill)
        {
            if (lastCheckedSkill != skill)
            {
                lastCheckedSkill = skill;
                Log.Message($"UpdatePawnSkill:{skill.defName}");
                return true;
            }
            return false;
        }
        /// <summary>
        /// Add the tool to the pawn
        /// </summary>
        /// <param name="equipped"></param>
        /// <param name="isUsingTool"></param>
        public void UpdateUsingTool(Thing equipped, bool isUsingTool)
        {
            if (previousEquipped == null)
                previousEquipped = equipped;
            usingTool = isUsingTool;
            Log.Message($"usingTool:{usingTool}");
        }
        /// <summary>
        /// Save properties of the class ToolMemory
        /// </summary>
        public void ExposeData()
        {
            Scribe_References.Look(ref pawn, "pawn");
            Scribe_Values.Look(ref usingTool, "usingTool");
            Scribe_Defs.Look(ref lastCheckedSkill, "lastCheckedSkill");
            Scribe_References.Look(ref previousEquipped, "previousEquipped");
        }
        #endregion
    }
}
